﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebERPPrintSample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Interop.StdPlatBS900.StdPlatBS plat_;
        Interop.StdPlatBS900.StdBSConfApl conf_;

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ImprimeListagem();
        }

        private void ImprimeListagem()
        {
            lblOutput.Text = string.Empty;

            StringBuilder strFormula_ = new StringBuilder();
            StringBuilder strParametros_ = new StringBuilder();
            StringBuilder strSelFormula_ = new StringBuilder();

            try
            {
                string sComp = txtEmpresa.Text;

                plat_ = new Interop.StdPlatBS900.StdPlatBS();
                conf_ = new Interop.StdPlatBS900.StdBSConfApl();
                
                conf_.AbvtApl = "GCP";
                conf_.Instancia = "default";
                conf_.Utilizador = txtUtil.Text;
                // não pode ser feito como estão a fazer porque a password passada é encripatada e aqui tem que ser plaintext
                //conf_.PwdUtilizador = bso_.Contexto.PasswordUtilizadorActual;
                conf_.PwdUtilizador = txtPassword.Text;
                conf_.LicVersaoMinima = "09.00";

                Interop.StdBE900.StdBETransaccao oTrans = null;
                Interop.StdBE900.EnumTipoPlataforma oTipo = 0;

                plat_.AbrePlataformaEmpresa(sComp, oTrans, conf_, 0, string.Empty);
                //plat_.AbrePlataformaEmpresaIntegrador(ref sComp, ref oTrans, ref conf_, ref oTipo);
                
                strSelFormula_ = new StringBuilder("{CabecDoc.TipoDoc}='" + txtDoc.Text + "' and {CabecDoc.Serie} = '"+txtSerie.Text+"' AND {CabecDoc.NumDoc}=" + txtNum.Text);

                plat_.Mapas.Inicializar("GCP");
                strFormula_.Append("StringVar Nome:='" + plat_.Contexto.Empresa.IDNome + "';");
                strFormula_.Append("StringVar Morada:='" + plat_.Contexto.Empresa.IDMorada + "';");
                strFormula_.Append("StringVar Localidade:='" + plat_.Contexto.Empresa.IDLocalidade + "';");
                strFormula_.Append("StringVar CodPostal:='" + plat_.Contexto.Empresa.IDCodPostal + " " + plat_.Contexto.Empresa.IDCodPostalLocal + "';");
                strFormula_.Append("StringVar Telefone:='" + plat_.Contexto.Empresa.IDTelefone + "';");
                strFormula_.Append("StringVar Fax:='" + plat_.Contexto.Empresa.IDFax + "';");
                strFormula_.Append("StringVar Contribuinte:='" + plat_.Contexto.Empresa.IFNIF + "';");
                strFormula_.Append("StringVar CapitalSocial:='" + plat_.Contexto.Empresa.ICCapitalSocial + "';");
                strFormula_.Append("StringVar Conservatoria:='" + plat_.Contexto.Empresa.ICConservatoria + "';");
                strFormula_.Append("StringVar Matricula:='" + plat_.Contexto.Empresa.ICMatricula + "';");
                strFormula_.Append("StringVar MoedaCapitalSocial:='" + plat_.Contexto.Empresa.ICMoedaCapSocial + "';");

                plat_.Mapas.SetFormula("DadosEmpresa", strFormula_.ToString());

                strParametros_.Append("NumberVar TipoDesc;");
                strParametros_.Append("NumberVar DecQde;");
                strParametros_.Append("NumberVar DecPrecUnit;");
                strParametros_.Append("StringVar MotivoIsencao;");
                strParametros_.Append("BooleanVar UltimaPag;");
                strParametros_.Append("StringVar PRI_TextoCertificacao;");
                strParametros_.Append("TipoDesc:= 0;");
                strParametros_.Append("DecQde:=3;");
                strParametros_.Append("DecPrecUnit:=" + plat_.FuncoesGlobais.DaCasasDecimais("Moedas", "DecArredonda") + ";");
                //strParametros_.Append("MotivoIsencao:='" + plat_.Contexto.IFMotivoIsencao + "';");
                strParametros_.Append("UltimaPag:=False;");
                //strParametros_.Append("PRI_TextoCertificacao:='" + plat_.Comercial.Vendas.DevolveTextoAssinaturaDoc(TipoDoc, Serie, NumDoc, "000") + "';");

                string filep =@"C:\partilha\teste.pdf";

                plat_.Mapas.SetFormula("InicializaParametros", strParametros_.ToString());

                plat_.Mapas.set_Destino(0);
                plat_.Mapas.SetFileProp(Interop.StdPlatBS900.CRPEExportFormat.efPdf  ,ref filep);

                plat_.Mapas.ImprimeListagem(txtReport.Text, "Factura", "P", 1, "N", strSelFormula_.ToString(), 0, false, true);
            }
            catch (Exception e)
            {
                lblOutput.Text = e.ToString();
            }
            finally
            {
                plat_ = null;
                conf_ = null;
            }
        }
    }
}